
import { Component } from '@angular/core';
import {CommonService} from './common.service';
import { NgForm } from '@angular/forms';
import { FormControl, FormGroup, Validators} from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  allUser: Object;
  isEdit=false;
  title = 'FormValidation';   
  isValidFormSubmitted = false;  
  userObj={
    name:'',
    mobile:'',
    email:'',
    password:'',
    introduction:'',
    id:''
  };
  constructor(private commonService:CommonService){}
  ngOnInit(){
    this.getLatestUser();
  }
  addUser(formObj){
    console.log(formObj)
    this.commonService.createUser(formObj).subscribe((response)=>{
      this.getLatestUser();

    })
    location.reload();
  }
  getLatestUser(){
    this.commonService.getAllUser().subscribe((response)=>{
      this.allUser = response
    })
  }
  editUser(user){
    this.isEdit=true;
    this.userObj = user;
  }

  deleteUser(user){
    this.commonService.deleteUser(user).subscribe(()=>{
      this.getLatestUser();
    })
    location.reload();
  }
  updateUser(){
    this.isEdit = !this.isEdit;
    this.commonService.updateUser(this.userObj).subscribe(()=>{
      this.getLatestUser();

    })
    location.reload();
  
  }

  form = new FormGroup({
    name: new FormControl('', [Validators.required, Validators.minLength(3)]),
    email: new FormControl('', [Validators.required, Validators.email]),
    mobile: new FormControl('', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]),
    password: new FormControl('', [Validators.required, Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]),
    introduction: new FormControl('', Validators.required)
  });
  
  get f(){
    return this.form.controls;
  }

 }  